import java.io.*;

import ocsf.server.*;
import java.lang.*;
import common.*;

public class ServerConsole implements ChatIF
{
	 final public static int DEFAULT_PORT = 5555;
	 
	 EchoServer echo;
	 
	 public ServerConsole(int port) 
  {
    try 
    {
      echo= new EchoServer(port);
      echo.listen();
    } 
    catch(IOException exception) 
    {
      System.out.println("Error: Can't setup connection!"
                + " Terminating client.");
      System.exit(1);
    }
  }
  
  public void accept() 
  {
    try
    {
      
      BufferedReader fromConsole = 
        new BufferedReader(new InputStreamReader(System.in));
      String message;

      while(true) 
      {
      	
        message = fromConsole.readLine();
       
       	
        echo.handleMessageFromServerUI(message);
        this.display(message);
      }
    } 
    catch (Exception ex) 
    {
      System.out.println
        ("Unexpected error while reading from console!");
    }
  }
  
  public void display(String message) 
  {
    System.out.println("SERVER MSG> " + message);
  }
  
  public static void main(String[] args) 
  {
    int port = 0; //Port to listen on

    try
    {
      port = Integer.parseInt(args[0]); //Get port from command line
    }
    catch(Throwable t)
    {
      port = DEFAULT_PORT; //Set port to 5555
    }
	
    ServerConsole sv = new ServerConsole(port);
    
    try 
    {
      
      sv.accept();
    } 
    catch (Exception ex) 
    {
      System.out.println("ERROR - Could not listen for clients!");
    }
  }
	 
}