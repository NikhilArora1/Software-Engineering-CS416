// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

package client;

import ocsf.client.*;
import common.*;
import java.io.*;

/**
 * This class overrides some of the methods defined in the abstract
 * superclass in order to give more functionality to the client.
 *
 * @author Dr Timothy C. Lethbridge
 * @author Dr Robert Lagani&egrave;
 * @author Fran&ccedil;ois B&eacute;langer
 * @version July 2000
 */
public class ChatClient extends AbstractClient
{
  //Instance variables **********************************************
  
  /**
   * The interface type variable.  It allows the implementation of 
   * the display method in the client.
   */
  ChatIF clientUI; 
  	String name;

  
  //Constructors ****************************************************
  
  /**
   * Constructs an instance of the chat client.
   *
   * @param host The server to connect to.
   * @param port The port number to connect on.
   * @param clientUI The interface type variable.
   */
  
  public ChatClient(String name,String host, int port, ChatIF clientUI) 
    throws IOException 
  {
    super(host, port); //Call the superclass constructor
    this.clientUI = clientUI;
    openConnection();
    sendToServer("#login"+name);
  }

  
  //Instance methods ************************************************
    
  /**
   * This method handles all data that comes in from the server.
   *
   * @param msg The message from the server.
   */
  public void handleMessageFromServer(Object msg) 
  { 
  	
  	
    clientUI.display(msg.toString());
  }

  			 			
   
   
   public void handleMessageFromClientUI(String message)
  {	int len;
    len=message.length();
    char c= message.charAt(0);
    String s=" ";
    String ss=" ";
    String arg=" ";
       	if(len>1)
		    { s=message.substring(1);}
		   if(len>7)
		   {ss=message.substring(1,8);}
		   
		  	if(len>7)
		  	{arg=message.substring(8,(len));}
  		 
  
  if(c=='#')
  	{
	  	
	  	  if(s.equals("quit"))
  			{
  				try
  				{
  				
  					quit();
  				
  				}
  				catch(Exception e){}
  				
  			}
  			
  			 if(s.equals("logoff"))
  			{
  			    try
  			    {
  			    	
  			    	closeConnection();
  			    	
  			    }	
  			    catch(Exception e){}
  			}
  			 if(ss.equals("sethost"))
  			{
  				try
  				{
  					
  					setHost(arg);
  					
  				}
  				catch(Exception e){}
  			}
  			 if(ss.equals("setport"))
  			{
  				try
  				{
  					
  					setPort(Integer.parseInt(arg));
  				}
  				catch(Exception e){}
  			
  			}
  			 if(s.equals("login"))
  			{
  				 if(isConnected())
  				 {System.out.println("client already connected");
  				 System.exit(0);
  				 }
  				 else 
  				 {
  				 	try
  				 	{
  				 		
  				 		openConnection();
  				 	}
  				 	catch(Exception e){}
  				 }
  			}
  			 if(s.equals("gethost"))
  			{
  					System.out.println(getHost());
  			}
  			 if(s.equals("getport"))
  			{
  				
  				System.out.println(getPort());
  			}
  		
  	}
  		else
  		{
  			try
		    {
		      this.sendToServer(message);
		      
		    }
		    catch(IOException e)
		    {
		      clientUI.display
		        ("Could not send message to server.  Terminating client.");
		      quit();
		    }
  		}
  	}
  


  /**
   * This method handles all data coming from the UI            
   *
   * @param message The message from the UI.    
   */
 
  
  /**
   * This method terminates the client.
   */
  public void quit()
  {
    try
    {
      closeConnection();
    }
    catch(IOException e) {}
    System.exit(0);
  }


 public void connectionClosed()
 {
 	if(!isConnected())
 	{
 		
 		System.out.println(" disconnecting");
 	    
 	}
 }
 
 public void connectionException(Exception exception)
 {
 	System.out.println("server down quitting");
 	 System.exit(0);
 }
 }