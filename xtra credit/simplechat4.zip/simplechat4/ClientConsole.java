// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

import java.io.*;

import ocsf.client.*;
import java.lang.*;
import java.util.*;



 public class ClientConsole implements Observer
{
  //Class variables *************************************************
  
 
  final public static int DEFAULT_PORT = 5555;
  
  
  ObservableClient client;
  public static String name;

  
  
  public ClientConsole(String name,String host, int port) 
  {
    
      client= new ObservableClient(host, port);
     client.addObserver(this);
     
     try 
    {
     
    
     client.openConnection(); 
     client.sendToServer("login"+name);
     
      
    } 
    catch (Exception ex) 
    {
      System.out.println("ERROR - Could not connect");
    }
    
  }

  
 
  public void accept() 
  {
    try
    {
      
      BufferedReader fromConsole = 
        new BufferedReader(new InputStreamReader(System.in));
      String message;

      while(true) 
      {
      	
        message = fromConsole.readLine();
       
       	
        handleMessageFromClientUI(message);
      }
    } 
    catch (Exception ex) 
    {
      System.out.println
        ("Unexpected error while reading from console!");
    }
  }

  
  public void display(String message) 
  {
    System.out.println("> " + message);
  }

  

     public static void main(String[] args) 
  {
  	
    String host = "";
    int port = DEFAULT_PORT;  //The port number

    try
    {
    	name=args[0];
    	
    	try
    	{
    		host = args[1];
            port=Integer.parseInt(args[2]);
        }
      
      //to read port number from command line it is the second argument.
    
    catch(ArrayIndexOutOfBoundsException e)
    {
      host = "localhost";
  
    }
    ClientConsole chat= new ClientConsole(name,host, port);
    chat.accept();  //Wait for console data
  }
  catch(Exception ex)
  {
  	System.exit(1);
  }
}

 public void handleMessageFromClientUI(String message)
  {	int len;
    len=message.length();
    char c= message.charAt(0);
    String s=" ";
    String ss=" ";
    String arg=" ";
       	if(len>1)
		    { s=message.substring(1);}
		   if(len>7)
		   {ss=message.substring(1,8);}
		   
		  	if(len>7)
		  	{arg=message.substring(8,(len));}
  		 
  
  if(c=='#')
  	{
	  	
	  	  if(s.equals("quit"))
  			{
  				try
  				{
  					client.sendToServer("#OS:Client disconnected.");
  					client.sendToServer("login"+this.name);
  					quit();
  					
  				   
  					
  				
  				}
  				catch(Exception e){System.out.println("client quit");}
  				
  			}
  			
  			 if(s.equals("logoff"))
  			{
  			    try
  			    {
  			    	client.sendToServer("#OS:Client disconnected.");
  			    	client.closeConnection();
  			    	
  			    }	
  			    catch(Exception e){}
  			}
  			 if(ss.equals("sethost"))
  			{
  				try
  				{
  					
  					client.setHost(arg);
  					
  				}
  				catch(Exception e){}
  			}
  			 if(ss.equals("setport"))
  			{
  				try
  				{
  					
  					client.setPort(Integer.parseInt(arg));
  				}
  				catch(Exception e){}
  			
  			}
  			 if(s.equals("login"))
  			{
  				 if(client.isConnected())
  				 {System.out.println("client already connected");
  				 System.exit(0);
  				 }
  				 else 
  				 {
  				 	try
  				 	{
  				 		
  				 		client.openConnection();
  				 	}
  				 	catch(Exception e){}
  				 }
  			}
  			 if(s.equals("gethost"))
  			{
  					System.out.println(client.getHost());
  			}
  			 if(s.equals("getport"))
  			{
  				
  				System.out.println(client.getPort());
  			}
  		
  	}
  		else
  		{
  			try
		    {
		      client.sendToServer("log["+this.name+"] "+ message);
		      
		    }
		    catch(IOException e)
		    {
		    display
		        ("Could not send message to server.  Terminating client.");
		      quit();
		    }
  		}
  	}
  	
  	public void quit()
  {
    try
    { 
    	
        client.closeConnection();
       
    }
    catch(Exception e) {System.out.println("close");}
    System.exit(0);
  }
  
public void update(Observable ob,Object msg){
	
	if(ob==client)
 	{
 	String akhil=msg.toString();
 	
 
 	
 	
 	if (akhil.equals("#OC:Connection closed."))
        {
        	try
        	{
        		
            System.exit(0);
        	}
        	catch(Exception e){}
        }
        else {System.out.println(akhil);
        }
}
}}
//End of ConsoleChat class
