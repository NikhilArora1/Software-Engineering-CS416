// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

import java.io.*;

import ocsf.server.*;
import java.lang.*;
import java.util.*;

/**
 * This class overrides some of the methods in the abstract 
 * superclass in order to give more functionality to the server.
 *
 * @author Dr Timothy C. Lethbridge
 * @author Dr Robert Lagani&egrave;re
 * @author Fran&ccedil;ois B&eacute;langer
 * @author Paul Holden
 * @version July 2000
 */
public class EchoServer implements Observer
{
  //Class variables *************************************************
  
  /**
   * The default port to listen on.
   */
  final public static int DEFAULT_PORT = 5555;
  
  private static ObservableOriginatorServer oos;
  private List list=new ArrayList();

  
  //Constructors ****************************************************
  
  /**
   * Constructs an instance of the echo server.
   *
   * @param port The port number to connect on.
   */
   
  public EchoServer(int port) 
  {
    
   oos= new ObservableOriginatorServer(port);
   oos.addObserver(this);
   try 
    {
    	
      oos.listen(); //Start listening for connections
    } 
    catch (Exception ex) 
    {
      System.out.println("ERROR - Could not listen for clients!");
    }
   
   
   
  }

  
  
  
  public static void main(String[] args) 
  {
    int port = 0; //Port to listen on

    try
    {
      port = Integer.parseInt(args[0]); //Get port from command line
    }
    catch(Throwable t)
    {
      port = DEFAULT_PORT; //Set port to 5555
    }
	
    EchoServer sv = new EchoServer(port);
    
    try 
    {
      sv.accept(); //Start listening for connections
    } 
    catch (Exception ex) 
    {
      System.out.println("ERROR - Could not listen for clients!");
    }
  }
  
  
 
 public void accept() 
  {
    try
    {
      
      BufferedReader fromConsole = 
        new BufferedReader(new InputStreamReader(System.in));
      String message;

      while(true) 
      {
      	
        message = fromConsole.readLine();
       
       	
        this.handleMessageFromServerUI(message);
        this.display(message);
      }
    } 
    catch (Exception ex) 
    {
      System.out.println
        ("Unexpected error while reading from console!");
    }
  }
  
  public void display(String message) 
  {
    System.out.println("SERVER MSG> " + message);
  }
 
 public void update(Observable ob,Object msg)
 {
 	
 
 	if(ob==oos)
 	{
 	String akhil=msg.toString();
 	
 
 	
 	
 	if (akhil.equals(oos.SERVER_CLOSED))
        {
            System.exit(0);
        }
        else
    if (akhil.equals(oos.SERVER_STOPPED))
        {
            System.out.println("no new connections");
        }
        else
  if (akhil.equals(oos.CLIENT_EXCEPTION))
        {
            System.out.println(oos.CLIENT_DISCONNECTED);
            
        }
        else
   if (akhil.equals(oos.CLIENT_CONNECTED))
        {
            System.out.println("#OS:Client connected.");
        }
       else if (akhil.equals(oos.LISTENING_EXCEPTION))
        {
            System.out.println("exception");
        }
       
        else if (akhil.equals(oos.CLIENT_DISCONNECTED))
        {
            System.out.println("#OS:Client disconnected.");
          return;
        }
        else  if (akhil.equals(oos.SERVER_STARTED))
        {
            System.out.println("OS:Server started. port"+DEFAULT_PORT);
        }
       	
        else
        {
        	if(akhil.startsWith("login"))
        	{ 
        		if(list.contains(akhil.substring(5)))
        		{
        			try
	    			{
	    		
	    			int i= list.indexOf(akhil.substring(5));
	    			list.remove(i);
	    			}
	    			catch (Exception ex){}
        		}
	    		
        			else
        				list.add(akhil.substring(5));
        	}
        	else
        	{
        			System.out.println(akhil);
         			oos.sendToAllClients(akhil);
        	}
        
        }
 }
 }
 
 
 
  
  	public void handleMessageFromServerUI(String message)
  		{
  	  	int len;
  	  	
	    len=message.length();
	    char c= message.charAt(0);
	    String s=" ";
	    String ss=" ";
	    String arg=" ";
	    if(len>0)
		    { s=message.substring(1);}
		    if(len>6)
		    { ss=message.substring(1,8);}
		  	if(len>7)
		  	{ arg=message.substring(8,(len));}
  		 
	    
	    switch(c)
	    {
	    	case '#':
	    	{
	    		if(s.equals("quit"))
	    		{
	    			oos.serverClosed();
	    		}
	    		else
	    		if(s.equals("stop"))
	    		{
	    			
	    			oos.stopListening();
	    		}
	    		else
	    		if(s.equals("close"))
	    		{
	    			try
	    			{
	    			oos.close();
	    			}
	    			catch (Exception ex){}
	    		}
	    		else
	    		if(s.equals("start"))
	    		{
	    			if(!oos.isListening())
	    			{  try{
	    			    
	    				oos.listen();}
	    				catch (Exception ex){}
	    			}
	    			else 
	    			{ 
	    			System.out.println("already connected");
	    			
	    			}
	    		}
	    		else
	    		if(s.equals("getport"))
	    		{
	    			System.out.println(oos.getPort());
	    		}
	    		else
	    		if(ss.equals("setport"))
	    		{
	    			oos.setPort(Integer.parseInt(arg));
	    		}
	    		else
	    		break;	
	    	}
	    	
	    }
	    if(!(c=='#'))
	    {oos.sendToAllClients("SERVER MSG>"+message);}
  	
  		
  		
  	}
  
}
//End of EchoServer class
